from backend.auth import valid_token
print("TeamFlow demo: token accepted =", valid_token("teamflow"), flush=True)
