# TeamFlow development-loop demo

Run: python app.py
Test: python -m pytest -q

Fix backend/auth.py to return token == "teamflow".
