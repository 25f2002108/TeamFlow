from backend.auth import valid_token

def test_valid_token():
    assert valid_token("teamflow") is True

def test_invalid_token():
    assert valid_token("wrong") is False
