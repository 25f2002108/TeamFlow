def valid_token(token):
    # Demo exercise: accept the token "teamflow".
    return False
